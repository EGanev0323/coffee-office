<script setup>
import TallyMarks from './TallyMarks.vue'

/* Общата дъска в офиса: всеки колега с кафета и неговите чертички. */
defineProps({
  entries: { type: Array, required: true },
  currentUserId: { type: Number, default: null },
  loading: { type: Boolean, default: false }
})
</script>

<template>
  <section class="board" aria-labelledby="board-title">
    <h2 id="board-title" class="board-title">Кафета</h2>

    <TransitionGroup v-if="entries.length" name="board-row" tag="ul" class="board-rows">
      <li
        v-for="e in entries"
        :key="e.id"
        class="board-row"
        :class="{ 'is-me': e.id === currentUserId }"
      >
        <span class="board-name">
          {{ e.displayName }}<span v-if="e.id === currentUserId" class="visually-hidden"> (ти)</span>
        </span>
        <TallyMarks :count="e.balance" :max="30" size="sm" :unlimited="e.unlimited" />
        <span class="board-count" aria-hidden="true">{{ e.unlimited ? '' : e.balance }}</span>
      </li>
    </TransitionGroup>

    <p v-else-if="!loading" class="board-empty">
      Дъската е празна. Когато някой купи пакет, името му ще се появи тук.
    </p>
  </section>
</template>

<style scoped>
.board {
  background: #FDFDFB;
  border: 10px solid #CDD2D6;
  border-radius: 8px;
  box-shadow: inset 0 0 0 1px #BCC2C7, 0 0 0 1px #BCC2C7;
  padding: 1.25rem 1.75rem 1.75rem;
}
.board-title {
  font-family: var(--font-hand);
  font-weight: 700;
  font-size: 2.4rem;
  line-height: 1;
  margin-bottom: 1rem;
}

.board-rows { list-style: none; margin: 0; padding: 0; display: grid; gap: 0.6rem; }
.board-row {
  display: grid;
  grid-template-columns: minmax(8rem, 13rem) 1fr auto;
  align-items: center;
  gap: 1rem;
}
.board-name {
  font-family: var(--font-hand);
  font-weight: 700;
  font-size: 1.7rem;
  line-height: 1.1;
  overflow-wrap: anywhere;
}
.is-me .board-name {
  text-decoration: underline;
  text-decoration-color: var(--red);
  text-decoration-thickness: 2px;
  text-underline-offset: 5px;
}
.board-count {
  font-family: var(--font-hand);
  font-weight: 700;
  font-size: 1.5rem;
  color: var(--muted);
  min-width: 2ch;
  text-align: right;
}
.board-empty {
  font-family: var(--font-hand);
  font-weight: 700;
  font-size: 1.5rem;
  color: var(--muted);
}

/* ред, който изчезва при последното изпито кафе */
.board-row-enter-active { transition: opacity 0.4s ease-out; }
.board-row-leave-active { transition: opacity 0.6s ease-in; }
.board-row-enter-from, .board-row-leave-to { opacity: 0; }

.visually-hidden {
  position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap;
}

@media (max-width: 560px) {
  .board { padding: 1rem 1.1rem 1.25rem; border-width: 8px; }
  .board-row { grid-template-columns: 1fr auto; row-gap: 0.2rem; }
  .board-row :deep(.tally) { grid-column: 1 / -1; grid-row: 2; }
}
</style>
